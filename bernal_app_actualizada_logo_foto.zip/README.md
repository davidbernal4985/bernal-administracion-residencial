# BERNAL | Administración Residencial

Aplicación web adaptable a teléfono y computador para administrar propiedades, apartamentos, facturas, lecturas, pagos y recibos.

## Contenido
- `index.html`: prototipo funcional de interfaz; almacena registros en el navegador.
- `supabase/schema.sql`: esquema inicial de tablas para la futura base de datos en Supabase.

## Publicación de la interfaz
1. En tu repositorio de GitHub, sube `index.html` a la raíz (junto a `README.md`).
2. Ve a **Settings → Pages**.
3. En **Build and deployment**, selecciona **Deploy from a branch**.
4. Selecciona `main` y `/(root)`, guarda y espera a que GitHub publique.

## Limitaciones actuales
- El modo local usa `localStorage` del navegador: los datos no se sincronizan entre dispositivos y pueden perderse si se borran los datos del navegador.
- No contiene autenticación real, OCR, subida segura de facturas, reparto completo de diferencias de contadores, ni permisos multiusuario activos.
- El archivo SQL es un punto de partida, no una configuración de producción. Deben implementarse y probarse políticas RLS completas antes de almacenar información real.
- GitHub Pages sirve archivos estáticos; la lógica de autenticación y los datos compartidos necesitan un backend como Supabase.

No introduzcas datos reales sensibles hasta completar autenticación, seguridad y respaldo.


## Captura de facturas
El formulario de nueva factura permite elegir o tomar una foto desde un móvil. En esta versión la imagen comprimida queda guardada en el almacenamiento local del navegador; no se sincroniza ni se sube a Supabase todavía. Evita usar facturas reales hasta terminar la integración segura.

-- BERNAL | Esquema inicial para Supabase
-- Ejecutar solo después de revisar el diseño. No pegar claves secretas en el frontend.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  role text not null default 'pending' check (role in ('pending','admin','collaborator')),
  approved boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.properties (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  address text,
  allocation_method text not null check (allocation_method in ('submeters','occupants')),
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.property_members (
  property_id uuid not null references public.properties(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  access_level text not null default 'viewer' check (access_level in ('manager','viewer')),
  approved_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  primary key(property_id,user_id)
);

create table if not exists public.apartments (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references public.properties(id) on delete cascade,
  name text not null,
  responsible_name text,
  occupants integer not null default 0 check (occupants >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.utility_bills (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references public.properties(id) on delete cascade,
  service text not null check (service in ('Enel','Acueducto','Vanti','Otro')),
  billing_period text,
  amount numeric(12,2) not null check (amount >= 0),
  issue_date date,
  due_date date,
  storage_path text,
  extracted_data jsonb not null default '{}'::jsonb,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.meter_readings (
  id uuid primary key default gen_random_uuid(),
  apartment_id uuid not null references public.apartments(id) on delete cascade,
  service text not null check (service in ('Enel','Acueducto','Vanti')),
  billing_period text not null,
  previous_reading numeric(14,3) not null check (previous_reading >= 0),
  current_reading numeric(14,3) not null check (current_reading >= previous_reading),
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  apartment_id uuid not null references public.apartments(id) on delete cascade,
  concept text not null,
  amount numeric(12,2) not null check (amount > 0),
  paid_at date not null default current_date,
  method text,
  reference text,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.receipts (
  id uuid primary key default gen_random_uuid(),
  apartment_id uuid not null references public.apartments(id) on delete cascade,
  receipt_number text not null unique,
  billing_period text,
  concept text not null,
  amount numeric(12,2) not null check (amount >= 0),
  status text not null default 'draft' check (status in ('draft','sent','paid','void')),
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.audit_log (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references auth.users(id),
  table_name text not null,
  record_id uuid,
  action text not null,
  before_data jsonb,
  after_data jsonb,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.properties enable row level security;
alter table public.property_members enable row level security;
alter table public.apartments enable row level security;
alter table public.utility_bills enable row level security;
alter table public.meter_readings enable row level security;
alter table public.payments enable row level security;
alter table public.receipts enable row level security;
alter table public.audit_log enable row level security;

-- Base de seguridad: el usuario solo puede leer su perfil; el acceso a datos
-- de propiedades se habilitará con políticas revisadas para admin y miembros.
create policy "Users can read own profile" on public.profiles
for select to authenticated using (id = auth.uid());

-- IMPORTANTE: No se habilitan políticas de escritura abiertas. Antes de producción
-- hay que crear políticas admin/member y una función segura para aprobar usuarios.
